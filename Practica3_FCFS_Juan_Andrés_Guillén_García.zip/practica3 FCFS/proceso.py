class Proceso:
    def __init__(self):
        self.nombre = ''
        self.tiempo_lleg = 0
        self.tiempo = 0
        self.tiempo_fal = 0
        self.inicio = 0
        self.fin = 0
        self.espera = 0