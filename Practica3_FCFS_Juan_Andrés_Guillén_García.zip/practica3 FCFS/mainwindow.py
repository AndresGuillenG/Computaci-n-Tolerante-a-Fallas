from PySide6.QtWidgets import QMainWindow
from PySide6.QtCore import Slot, QTimer
from ui_mainwindow import Ui_MainWindow
from PySide6.QtWidgets import QMainWindow
from random import randint
import time

from proceso import Proceso

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow,self).__init__()

        self.t_total = 0     #contador de tiempo
        self.caballos = []  
        self.espera = []
        self.terminados = []
        #declara caballos
        self.c1 = Proceso()
        self.c2 = Proceso()
        self.c3 = Proceso()
        self.c4 = Proceso()
        #nombrar caballos
        self.c1.nombre = 'Caballo 1'
        self.c2.nombre = 'Caballo 2'
        self.c3.nombre = 'Caballo 3'
        self.c4.nombre = 'Caballo 4'
        

        #crear la ui
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        #Crear timer para mover la ui
        self.timer = QTimer(self)

        # concecion de botones con una funcion
        self.ui.restart_pushButton.clicked.connect(self.restart)
        self.ui.start_pushButton.clicked.connect(self.start)

    #Funcion para reiniciar el programa
    @Slot( )
    def restart(self):
        self.timer.stop() 
        self.ui.info_label.clear()
        self.ui.posiciones_label.clear()
        #restablecer datos
        self.t_total = 0
        self.caballos = []  
        self.espera = []
        self.terminados = []
        #declara caballos
        self.c1 = Proceso()
        self.c2 = Proceso()
        self.c3 = Proceso()
        self.c4 = Proceso()
        #nombrar caballos
        self.c1.nombre = 'Caballo 1'
        self.c2.nombre = 'Caballo 2'
        self.c3.nombre = 'Caballo 3'
        self.c4.nombre = 'Caballo 4'
        self.start()

    #Funcion para iniciar el programa
    @Slot( )
    def start(self):
        #reiniciar posiciones de los caballos
        self.ui.caballo1_label.move(60,10)
        self.ui.caballo2_label.move(60,150)
        self.ui.caballo3_label.move(60,290)
        self.ui.caballo4_label.move(60,430)
        #asignar tiempo a acaballos
        self.c1.tiempo = randint(5,15)
        self.c2.tiempo = randint(5,15)
        self.c3.tiempo = randint(5,15)
        self.c4.tiempo = randint(5,15)

        self.c1.tiempo_fal = self.c1.tiempo
        self.c2.tiempo_fal = self.c2.tiempo
        self.c3.tiempo_fal = self.c3.tiempo
        self.c4.tiempo_fal = self.c4.tiempo

        #agragar al primer caballo al procesador
        self.c1.tiempo_lleg = self.t_total
        self.caballos.append(self.c1)

        #agregar los demas caballos al espera
        self.espera.insert(0,self.c2)
        self.espera.insert(0,self.c3)
        self.espera.insert(0,self.c4)

        #iniciamos el timer
        self.timer.timeout.connect(self.mover_caballo)
        self.timer.start(1000)
    
    @Slot( )
    def mover_caballo(self):
        self.t_total += 1

        if self.caballos[0].tiempo_fal > 0:
            print(self.caballos[0].tiempo_fal)
            print()
            self.caballos[0].tiempo_fal -= 1
            
            paso = 900 // self.caballos[0].tiempo
            if self.caballos[0].nombre == 'Caballo 1':
                x = self.ui.caballo1_label.x()
                y = self.ui.caballo1_label.y()
                self.ui.caballo1_label.move(x+paso,y)
            elif self.caballos[0].nombre == 'Caballo 2':
                x = self.ui.caballo2_label.x()
                y = self.ui.caballo2_label.y()
                self.ui.caballo2_label.move(x+paso,y)
            elif self.caballos[0].nombre == 'Caballo 3':
                x = self.ui.caballo3_label.x()
                y = self.ui.caballo3_label.y()
                self.ui.caballo3_label.move(x+paso,y)
            elif self.caballos[0].nombre == 'Caballo 4':
                x = self.ui.caballo4_label.x()
                y = self.ui.caballo4_label.y()
                self.ui.caballo4_label.move(x+paso,y)

            for pony in self.espera:
                pony.espera += 1 

        elif len(self.espera) > 0:
            term = self.caballos.pop()
            term.fin = self.t_total
            self.terminados.append(term)

            new = self.espera.pop()
            new.tiempo_lleg = self.t_total - 1
            new.inicio = self.t_total
            self.caballos.append(new)

        else:
            term = self.caballos.pop()
            term.fin = self.t_total
            self.terminados.append(term)

            cad = ''
            cad2 = ''
            num = []
            for pony in self.terminados:
                cad += str(pony.nombre) +'\t||'+str(pony.tiempo_lleg)+'\t\t||'+str(pony.tiempo)+'\t\t||'+str(pony.inicio)+'\t||'+str(pony.fin)+'\t||'+str(pony.espera)+'\n'
            self.ui.info_label.setText('Proceso\t\t||TLlegada\t||Tiempo\t||Inicio\t||Fin\t||Espera\n'+cad)

            for pony in self.terminados:
                tup =(pony.tiempo,pony.nombre)
                num.append(tup)
            num.sort(key= lambda x: x[0])
            for x in num:
                cad2 += x[1] + ' - ' + str(x[0]) + '\n'
            self.ui.posiciones_label.setText(cad2)
            self.timer.stop() 